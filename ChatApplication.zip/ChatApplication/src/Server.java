/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Pavan
 */
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(2323);
        Socket socket = serverSocket.accept();
        Scanner fromConsole = new Scanner(System.in);

        Scanner fromClient = new Scanner(socket.getInputStream());
        PrintWriter toClient = new PrintWriter(socket.getOutputStream(), true); // Added 'true' for auto-flushing

        String inputFromClient, inputFromConsole;
        while (true) {
            inputFromClient = fromClient.nextLine();
            System.out.println("Client: " + inputFromClient);
            
            System.out.print("Server: ");
            inputFromConsole = fromConsole.nextLine();
            toClient.println(inputFromConsole);
            
            if (inputFromConsole.equalsIgnoreCase("exit")) {
                break;
            }
        }

        socket.close();
        serverSocket.close();
    }
}

